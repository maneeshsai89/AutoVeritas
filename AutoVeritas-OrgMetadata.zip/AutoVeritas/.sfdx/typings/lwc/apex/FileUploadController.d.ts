declare module "@salesforce/apex/FileUploadController.uploadFiles" {
  export default function uploadFiles(param: {recordId: any, filedata: any}): Promise<any>;
}
