import { LightningElement, track } from 'lwc';
import { loadStyle } from 'lightning/platformResourceLoader';
import animatecss from '@salesforce/resourceUrl/animatecss';

export default class CarRentalHome extends LightningElement {
    carImages = [
        { id: 1, url: '/resource/carImage', title: 'Hyundai Verna' },
        { id: 2, url: '/resource/carImageSUV', title: 'Hyndai Alcazar' },
        { id: 3, url: '/resource/carImageCompactSUV', title: 'Hyundai i20' }
    ];

    @track currentIndex = 0;
    slideInterval;

    connectedCallback() {
        this.startAutoSlide();
        this.preloadImages();

        loadStyle(this, animatecss)
            .then(() => {
                console.log('Animate.css loaded.');
            })
            .catch(error => {
                console.error('Error loading Animate.css', error);
            });
    }

    disconnectedCallback() {
        clearInterval(this.slideInterval);
    }

    startAutoSlide() {
        this.slideInterval = setInterval(() => {
            this.currentIndex = (this.currentIndex + 1) % this.carImages.length;
        }, 4000);
    }

    preloadImages() {
        this.carImages.forEach(image => {
            const img = new Image();
            img.src = image.url;
        });
    }

    get carouselStyle() {
        const offset = -(this.currentIndex * 100);
        return `transform: translateX(${offset}%); transition: transform 0.8s ease;`;
    }

    get indicators() {
        return this.carImages.map((img, index) => {
            return {
                id: img.id,
                className: index === this.currentIndex ? 'indicator active' : 'indicator'
            };
        });
    }
    /*renderedCallback() {
        const style = document.createElement('style');
        style.innerText = `
        .slds-col--padded.comm-content-header.comm-layout-column {
        padding: 0px !important;
            } 
        `;
        this.template.querySelector('body').appendChild(style);
    }*/
}