import {LightningElement,api,wire,track} from 'lwc';
import uploadFiles from '@salesforce/apex/FileUploadController.uploadFiles';
import { CurrentPageReference } from 'lightning/navigation';
import { showToastEvent } from 'lightning/platformShowToastEvent';
import LightningAlert from 'lightning/alert';

const MAX_FILE_SIZE = 2097152;

export default class Fileupload extends LightningElement {
    @track recordId;
    @track filesData = [];
    showSpinner = false;

    @wire(CurrentPageReference)
        getStateParameters(currentPageReference) {
            if (currentPageReference) {
                    const urlValue = currentPageReference.state.c__recordId;
            if (urlValue) {
                    this.recordId = urlValue;
                } 
        }
    }
 
    handleFileUploaded(event) {
        if (event.target.files.length > 0) {
            for(var i=0; i< event.target.files.length; i++){
                if (event.target.files[i].size > MAX_FILE_SIZE) {
                    //this.showToast('Error!', 'error', 'File size exceeded the upload size limit.');
                    return;
                }
                let file = event.target.files[i];
                let reader = new FileReader();
                reader.onload = e => {
                    var fileContents = reader.result.split(',')[1]
                    this.filesData.push({'fileName':file.name, 'fileContent':fileContents});
                };
                reader.readAsDataURL(file);
            }
        }
    }
 
    uploadFiles() {
        console.log('filesdata>>>'+JSON.stringify(this.filesData));
        console.log('reocrdId',this.recordId);
        if(this.filesData == [] || this.filesData.length == 0) {
            //this.showToast('Error', 'error', 'Please select files first'); return;
        }
        this.showSpinner = true;
        uploadFiles({
            recordId : this.recordId,
            filedata : JSON.stringify(this.filesData)
        })
        .then(result => {
            console.log(result);
            if(result && result == 'success') {
                this.filesData = [];
                //window.close();
                LightningAlert.open({
                    message: 'Files Uploaded Successfully!',
                    theme: 'success',
                    variant: 'header',
                    label: 'Success!'
                });
                /*const evt = new showToastEvent(
                    {
                        title : 'Success',
                        message : 'Files Uploaded Successfully!',
                        variant : 'success',
                        mode : 'dismissable',  
                    });
                this.dispatchEvent(evt);*/
            } 
        }).catch(error => {
            console.log('error>>>'+JSON.stringify(error));
            
        }).finally(() => this.showSpinner = false );
    }
 
    removeReceiptImage(event) {
        var index = event.currentTarget.dataset.id;
        this.filesData.splice(index, 1);
    }
}